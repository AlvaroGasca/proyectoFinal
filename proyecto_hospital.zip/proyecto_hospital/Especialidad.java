/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package proyecto_hospital;

/**
 *
 * @author alvarogasca
 */
public enum Especialidad {
    Alergología, AnestesiologíaReanimación, AparatoDigestivo, Cardiología, EndocrinologíaNutrición, Geriatría, HematologíaHemoterapia, MedicinaEducaciónFísicaDeporte, MedicinaEspacial, MedicinaIntensiva, MedicinaInterna, MedicinaLegalForense, MedicinaPreventivaSaludPublica, MedicinaTrabajo, Nefrología, Neumología, Neurología, NeurofisiologíaClínica, OncologíaMédica, OncologíaRadioterápica, Pediatría, Psiquiatría, Rehabilitación, Reumatología, MedicinaFamiliarComunitaria, CirugíaCardiovascular, CirugíaGeneralAparatoDigestivo, CirugíaOralMaxilofacial, CirugíaOrtopédicaTraumatología, CirugíaPediátrica, CirugíaPlásticaEstéticaReparadora, CirugíaTorácica, Neurocirugía, AngiologíaCirugíaVascular, DermatologíaMédicoquirúrgicaVenereología, ObstetriciaGinecología, Oftalmología, Otorrinolaringología, Urología, AnálisisClínicos, AnatomíaPatológica, BioquímicaClínica, FarmacologíaClínica, Inmunología, MedicinaNuclear, MicrobiologíaParasitología, Radiodiagnóstico
    
}
