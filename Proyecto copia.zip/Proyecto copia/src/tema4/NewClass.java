/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema4;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class NewClass {
    public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
int nota;
int suspensos=0;
for(int i=1;i<=5;i++){
    System.out.println("Introduce la nota");
nota=sc.nextInt();
if(nota<5){
    System.out.println("Suspenso");
suspensos++;
}
if(nota>=5){
    System.out.println("Aprobado");
}
}
        System.out.println("El numero de suspensos es: " + suspensos);
}
    }



