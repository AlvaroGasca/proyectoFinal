/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema4;

/**
 *
 * @author alvarogasca
 */
public class Entre_enteros {
    static void numeros(int a, int b){
        while (a<b){
        a++;
        System.out.println(a);
        
        if(b-1==a){
            break;
        }
        }
        
        while (a>b){
        b++;
        System.out.println(b);
        
        if(a-1==b){
        break;
        }
        }
    }
    
    public static void main(String[] args) {
        numeros(2,1);
    }
}
    

