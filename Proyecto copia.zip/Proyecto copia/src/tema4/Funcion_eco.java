/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema4;

/**
 *
 * @author alvarogasca
 */
public class Funcion_eco {
    static void eco(int n){
        for(int i=0;i<n;i++){
            System.out.println("Eco...");
        }
    }
    
    public static void main(String[] args) {
        eco(8);
    }
}
