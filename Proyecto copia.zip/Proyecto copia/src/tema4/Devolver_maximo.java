/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema4;

/**
 *
 * @author alvarogasca
 */
public class Devolver_maximo {
    static int maximo(int a, int b){
        int resultado;
        if (a<b){
            //System.out.println("El numero mayor es " + b);
            resultado = b;
        }
        else {
            //System.out.println("El numrto mayor es " + a);
            resultado = a;
        }
        return resultado;
    }
    static int maximo(int a, int b, int c){
        int res;
        res=maximo(maximo(a,b),c);
        return res;
    }
    public static void main(String[] args) {
        int numero;
       numero = maximo(4,9,12);
        System.out.println(numero);
        //System.out.println(maximo(8,15));
    }
    
}
