/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema4;

import java.time.LocalDateTime;

/**
 *
 * @author alvarogasca
 */
public class Vivido {
public static void main (String[] args){
System.out.println(horas (2003,10,27));
}
public static int horas (int anno, int mes, int dia){
int resultado;
LocalDateTime fecha = LocalDateTime.now();
int annno = fecha.getYear();
int day = fecha.getDayOfYear(); //Dia actual en el afño 318
int edad = ((annno-anno)-1)*365;
resultado =edad*24 + day*24;
return resultado;
}
}
