/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema4;

/**
 *
 * @author alvarogasca
 */
public class Mcd {

public static void main (String[] Args) {
    
        System.out.println("El mcd es "+obtener_mcd(8,12));
    }
   
    static int obtener_mcd(int a, int b) {
       if(b==0)
           return a;
       if (a==0)
           return b;
       else
           return obtener_mcd(b, a % b);
   }
}

    

