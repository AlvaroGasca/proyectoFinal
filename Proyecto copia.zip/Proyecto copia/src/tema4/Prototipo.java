/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema4;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Prototipo {
    public static void main(String[] args) {
    // TODO code application logic here
    Scanner sc=new Scanner(System.in);
    int num;
    System.out.println("Escribe un numero");
    num=sc.nextInt();
    if (esprimo(num)){
        System.out.println("Es primo ");
    }else{
        System.out.println("No es primo");
        }
    }
    
public static boolean esprimo(int numero) {
    boolean resultado=true;
    if (numero == 0 || numero == 1 || numero == 4) {
        resultado=false;
    }
    for (int x = 2; x < numero / 2; x++) {
        if (numero % x == 0)
        resultado=false;
        }
    return resultado;
    }
}
