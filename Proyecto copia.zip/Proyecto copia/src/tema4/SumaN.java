/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema4;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class SumaN {
    static int suma(int a){
        int res;
        if (a==1){
            res=1;
        }else{
            res=a+suma(a-1);
        }
        return res;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Introduce un numero");
        int a = sc.nextInt();
        int res = suma(a);
        System.out.println("El resultado de " + a + "! es: "+ res);
    }
    
}
