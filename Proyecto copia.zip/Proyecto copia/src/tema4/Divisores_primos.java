/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema4;

/**
 *
 * @author alvarogasca
 */
public class Divisores_primos {

	static boolean esPrimo(int num){ //si sale true es que es primo
              boolean primo = true;
	      int i = 2; 

	      if (num < 2) { 
	         primo = false;
	      }

	      while (i < num && primo == true) { 
	         if (num % i == 0) { 
	            primo = false; 
	         }
	         i++;
	      }

	      return (primo);
	}

	static int numeroDivisoresPrimos(int num){
            int cont = 0; 

            for (int i = 2; i <= num; i++) {
               if (esPrimo(i) && num % i == 0) { 
                  cont++;    
               }
            }
            return (cont);

	}

	public static void main(String[] args) {
	   
            int res = numeroDivisoresPrimos(20);
            System.out.println(res);
	}
}
