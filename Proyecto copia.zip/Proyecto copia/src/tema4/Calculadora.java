/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema4;


/**
 *
 * @author alvarogasca
 */
public class Calculadora{ 
        static double Operar(double a, double b, int signo){
            double resultado=0;
            switch(signo){
                case 1: 
                    resultado = a + b; break;
                case 2: 
                    resultado = a - b; break;
                case 3: 
                    resultado = a * b; break;
                case 4: 
                    resultado = a / b; break;
            }
            return resultado;
        }
        
        public static void main(String[] args) {
            System.out.println(Operar(2,3,1));
    }
}
