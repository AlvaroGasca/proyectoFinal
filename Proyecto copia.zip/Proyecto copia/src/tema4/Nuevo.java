/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema4;

/**
 *
 * @author alvarogasca
 */
public class Nuevo {
    static void tresSaludos(){
        for(int i=0; i<3; i++){
            System.out.println("Holi");
            
        }
    }
    
    static void variosSaludos(int nveces){
        for(int i=0; i<nveces;i++){
            System.out.println("Holi");
        }
    }
    
    public static void main(String[] args) {
        tresSaludos();
        
        variosSaludos(122);
    }
}
