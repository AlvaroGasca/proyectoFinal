/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema7.warrior;

/**
 *
 * @author alvarogasca
 */
public class Guerrero extends Personaje{
    private int armadura;
    private String arma;
    
    public Guerrero(){
    }
    
    public Guerrero(String nombre, int vida, int fuerza, int armadura, String arma){
        super(nombre,vida,fuerza);
        this.arma=arma;
        this.armadura=armadura;
    }
    
    public int getArmadura(){
        return armadura;
    }
    
    public void setArmadura(int armadura){
        this.armadura=armadura;
    }
    
    public String getArma(){
        return arma;
    }
    
    public void setArma(String arma){
        this.arma=arma;
    }
    
    @Override
    public void atacar(){
        System.out.println("El guerrero " +nombre+ " esta atacando");
    }

    @Override
    public void defender() {
        System.out.println("El guerrero " +nombre+ " esta defendiendo");
    }
}
