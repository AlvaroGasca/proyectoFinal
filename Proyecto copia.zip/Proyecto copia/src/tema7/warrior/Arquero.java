/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema7.warrior;

/**
 *
 * @author alvarogasca
 */
public class Arquero extends Personaje{
    private int punteria;
    private String arco;
    
    public Arquero(){
    }
    
    public Arquero(String nombre, int vida, int fuerza, int punteria, String arco){
        super(nombre,vida,fuerza);
        this.arco=arco;
        this.punteria=punteria;
    }
    
    public int getPunteria(){
        return punteria;
    }
    
    public void setPunteria(int punteria){
        this.punteria=punteria;
    }
    
    public String getArco(){
        return arco;
    }
    
    public void setArco(String arco){
        this.arco=arco;
    }
    
    @Override
    public void atacar(){
        System.out.println("El arquero " + getNombre() + " esta atacando");
    }
    
    @Override
    public void defender(){
        System.out.println("El arquero " +nombre+ " esta defendiendo");
    }
}
