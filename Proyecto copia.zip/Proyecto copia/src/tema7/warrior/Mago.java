/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema7.warrior;

/**
 *
 * @author alvarogasca
 */
public class Mago extends Personaje{
    private int magia;
    private String barita;
    
    public Mago(){
    }
    
    public Mago(String nombre, int vida, int fuerza, int magia, String barita){
        super(nombre,vida,fuerza);
        this.barita=barita;
        this.magia=magia;
    }
    
    public int getMagia(){
        return magia;
    }
    
    public void setMagia(int magia){
        this.magia=magia;
    }
    
    public String getBarita(){
        return barita;
    }
    
    public void setBarita(String barita){
        this.barita=barita;
    }
    
    @Override
    public void atacar(){
        System.out.println("El mago " +nombre+ " esta atacando");
    }
    
    @Override
    public void defender(){
        System.out.println("El mago " +nombre+ " esta defendiendo");
    }
    
}
