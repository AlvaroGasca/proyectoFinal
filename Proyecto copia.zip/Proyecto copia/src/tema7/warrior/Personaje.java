/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema7.warrior;

/**
 *
 * @author alvarogasca
 */
public abstract class Personaje {
    protected String nombre;
    protected int vida;
    protected int fuerza;
    
    public Personaje(){
    }
    
    public Personaje(String nombre, int vida, int fuerza){
        this.fuerza=fuerza;
        this.nombre=nombre;
        this.vida=vida;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    
    public int getVida(){
        return vida;
    }
    
    public void setVida(int vida){
        this.vida=vida;
    }
    
    public int getFuerza(){
        return fuerza;
    }
    
    public void setFuerza(int fuerza){
        this.fuerza=fuerza;
    }
    
    public abstract void atacar();
    
    public abstract void defender();
}
