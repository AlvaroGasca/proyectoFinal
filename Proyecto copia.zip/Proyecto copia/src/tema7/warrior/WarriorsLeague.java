/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema7.warrior;

/**
 *
 * @author alvarogasca
 */
public class WarriorsLeague {
    public static void main(String[] args) {
        
        Guerrero g1 = new Guerrero("Anto", 100, 10, 8, "Espada");
        Arquero a1 = new Arquero("Filo", 100, 7, 10, "Madera");
        Mago m1 = new Mago("Fulo", 120, 12, 7, "Sauko");
        Mago m2 = new Mago("Rise", 110, 10, 9, "Roble");
        g1.atacar();
        g1.defender();
        
        a1.atacar();
        a1.defender();
        
        m1.atacar();
        m1.defender();
        
        System.out.println(m1.equals(m2));
        //Los magos "Fulo" y "Rise" son iguales a cuanto su construccion base, ambos
        //usan magia y barita, y vinen de la misma herencia, Personaje. 
        //Pero a modo de caracteristicas son diferentes, ya que tienen
        //diferentes nombres, daño, vida, fuerza, magia y varita.
        
    }
}
