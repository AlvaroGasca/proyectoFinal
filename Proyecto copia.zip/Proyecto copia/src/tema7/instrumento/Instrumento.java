/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema7.instrumento;

import java.util.ArrayList;

/**
 *
 * @author alvarogasca
 */
public abstract class Instrumento {
    protected ArrayList<Nota> melodia;

    public Instrumento() {
        melodia = new ArrayList<Nota>();
    }

    public void add(Nota nota) {
        melodia.add(nota);
    }

    public abstract void interpretar();

    public enum Nota {
        DO, RE, MI, FA, SOL, LA, SI
    }
}

