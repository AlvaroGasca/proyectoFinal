/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema7.hospital;

/**
 *
 * @author alvarogasca
 */
public class Cirujano extends Medico{
    private static final double CFIJ=1700.0;
    
    public Cirujano(){
    }

    public Cirujano(Especialidad especialidad, int nc, int np, String nombre, String id, double sueldo) {
        super(especialidad, nc, np, nombre, id, sueldo);
    }

    @Override
    public void calcularSueldo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}
