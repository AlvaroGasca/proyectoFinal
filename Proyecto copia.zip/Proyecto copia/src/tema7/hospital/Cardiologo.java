/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema7.hospital;

/**
 *
 * @author alvarogasca
 */
public class Cardiologo extends Medico{
    private static final double CFIJ=1200.0;
    
    public Cardiologo(){
    }
    public Cardiologo(Especialidad especialidad, int nc, int np, String nombre, String id, double sueldo) {
        super(especialidad, nc, np, nombre, id, sueldo);
    }
    
    @Override
    public void calcularSueldo(){
        super.setSueldo(CFIJ + (getNp()*5)); 
    }
    
    
}
