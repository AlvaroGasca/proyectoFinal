/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema5;

import java.util.Arrays;

/**
 *
 * @author alvarogasca
 */
public class Longitud {
    public static void main(String[] args) {
        int a=10;
        int tabla[];
        tabla = new int [a];
        System.out.println(a);
        System.out.println(Arrays.toString(tabla));
        
    }
    
}
