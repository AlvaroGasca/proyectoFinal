/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema5;

import java.util.Arrays;

/**
 *
 * @author alvarogasca
 */
public class Ordenar {
    public static void main(String[] args) {
        int a[]={5,7,8,4,3,6,0,0,8,1};
        Arrays.sort (a);
        System.out.println(Arrays.toString(a));
    }
    
}
