/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema5;

import java.util.Arrays;

/**
 *
 * @author alvarogasca
 */
public class T150 {
    public static void main(String[] args) {
        boolean a [];
        a = new boolean[150];
        for(int i=0;i<150;i++){
            a[i]=false;
        }
        System.out.println(Arrays.toString(a));
        
//        Arrays.fill(a, false);
    }  
}
