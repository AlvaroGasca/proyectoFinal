/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema5;

/**
 *
 * @author alvarogasca
 */
public class Random100 {
    public static void main(String[] args) {
       int valores[];
       valores = new int[10];
      
       for (int i = 0; i < valores.length; i++) {
           valores[i] = (int)(Math.random()*100 + 1);
       }
      
       int suma = 0; //acumulador
       for(int valor: valores) {
           suma += valor;
       }
      
       System.out.println("La suma de los aleatorios es " + suma);
   }   
    
}
