/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema5;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Dos_matrices{ 
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int matri[][];
        matri = new int[5][5];
        int matri2[][];
        matri2 = new int[5][5];
        int matri3[][];
        matri3 = new int[5][5];
        System.out.println("Rellene la tabla");
        for (int i = 0; i < 5; i++) {
            for (int e = 0; e < 5; e++) {
                matri[i][e] = sc.nextInt();
            }
        }
        System.out.println(Arrays.toString(matri[0]));
        System.out.println(Arrays.toString(matri[1]));
        System.out.println(Arrays.toString(matri[2]));
        System.out.println(Arrays.toString(matri[3]));
        System.out.println(Arrays.toString(matri[4]));

        System.out.println("Rellene la tabla");
        for (int i = 0; i < 5; i++) {
            for (int e = 0; e < 5; e++) {
                matri2[i][e] = sc.nextInt();
            }
        }
        System.out.println(Arrays.toString(matri2[0]));
        System.out.println(Arrays.toString(matri2[1]));
        System.out.println(Arrays.toString(matri2[2]));
        System.out.println(Arrays.toString(matri2[3]));
        System.out.println(Arrays.toString(matri2[4]));

        System.out.println("Tabla de solucion");
        for (int i = 0; i < 5; i++) {
            for (int e = 0; e < 5; e++) {
                matri3[i][e] = matri[i][e] + matri2[i][e];
            }
        }
        System.out.println(Arrays.toString(matri3[0]));
        System.out.println(Arrays.toString(matri3[1]));
        System.out.println(Arrays.toString(matri3[2]));
        System.out.println(Arrays.toString(matri3[3]));
        System.out.println(Arrays.toString(matri3[4]));
    }
}
    

