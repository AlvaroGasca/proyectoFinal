/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema5;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Valor_maximo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a[][];
        a = new int [3][4];
        System.out.println("Rellene la tabla: ");
        for (int i = 0; i < 3; i++) {
        for (int e = 0; e < 4; e++) {
            a[i][e] = sc.nextInt();
        }
    }
    
        int x = a.length;
        int y = a[2].length;
}
}
