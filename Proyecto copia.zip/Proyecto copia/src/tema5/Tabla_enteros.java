/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema5;

/**
 *
 * @author alvarogasca
 */
public class Tabla_enteros {
    static int buscar(int a[], int x){
        int res=-1;
        for(int i=0; i<a.length; i++){
            if(a[i]==x){
                res=i;
            }
        }
        return res;
    }
    
    public static void main(String[] args) {
        int a []={1,2,3,4,5,6,7,8,9};
        System.out.println("El elemento buscado es " + buscar(a,9));
    }
    
}
