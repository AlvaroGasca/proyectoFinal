/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema5;

import java.util.Arrays;

/**
 *
 * @author alvarogasca
 */
public class Tabla {
    public static void main(String[] args) {
        int ji [] = {1,2,3,4,5};
        System.out.println(Arrays.toString(ji));
        double jo [] = {1.1,2.2,3.3,4.4,5.5};
        System.out.println(Arrays.toString(jo));
        boolean ju [] = {true,true,true,false,false};
        System.out.println(Arrays.toString(ju));
    }
    
}
