/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema5;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Teclado5 {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        double a [];
        a = new double[5];
        System.out.println("Inserta 5 numeros: ");
        for (int i = 0; i < a.length; i++) {
           a[i] = (double)(sc.nextDouble());
       }
        System.out.println(Arrays.toString(a));
    }
    
}
