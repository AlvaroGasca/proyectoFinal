/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema5;

import java.util.Arrays;

/**
 *
 * @author alvarogasca
 */
public class Tabla_mas1 {
    static int [] unomas(int t[],int a){ 
    int t2[] = new int [t.length+1];
    for(int i=0; i<t.length;i++){
        t2[i]=t[i];
    }
    t2[t.length]=a;
    return t2;
}
    public static void main(String[] args) {
     int t[]= {1,2,3,4,5};
        System.out.println(Arrays.toString(unomas(t,2)));
    }
}
