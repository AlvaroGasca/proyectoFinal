/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema5;

import java.util.Arrays;

/**
 *
 * @author alvarogasca
 */
public class T900 {
    public static void main(String[] args) {
        int a [];
        a = new int[901];  
        for(int i=0;i<900;i++){
        a[i]=i;
        }
        System.out.println(Arrays.toString(a));
    }
    
}
