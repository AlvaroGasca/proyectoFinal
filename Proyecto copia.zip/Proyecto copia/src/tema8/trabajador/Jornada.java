/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema8.trabajador;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;


/**
 *
 * @author alvarogasca
 */
public class Jornada implements comparable{
    String dni;
    LocalDate fecha;
    LocalTime entrada;
    LocalTime salida;

    public Jornada(String dni, LocalDate fecha, LocalTime entrada, LocalTime salida) {
        this.dni = dni;
        this.fecha = fecha;
        this.entrada = entrada;
        this.salida = salida;
    }
    
    public double Minutos(){
     return (int) entrada.until(salida, ChronoUnit.MINUTES);
    }
    
    public int compareTo(Object ob) {
        int res = dni.compareTo(((Jornada) ob).dni);
        if (res == 0) {
            res = fecha.compareTo(((Jornada) ob).fecha);
        }
        return res;
    }

    @Override
    public String toString() {
        return "\nDNI: " + dni + " fecha: " + fecha
                + " minutos trabajados: " + Minutos();
    }
    
    
    
}
