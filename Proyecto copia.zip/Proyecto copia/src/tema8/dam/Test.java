/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema8.dam;

import java.util.Arrays;

/**
 *
 * @author alvarogasca
 */
public class Test {
    public static void main(String[] args) {
        
        Alumno a1 = new Alumno("Ana", "56384569A", "638763409", "ana@gmail.com", 8, "Bd 1, Pro 1");
        Alumno a2 = new Alumno("Pedro", "67456378R", "987654567", "perdro@gmail.com", 2, "Bd 2, Pro 2");
        Alumno a3 = new Alumno("Susan", "84399098L", "78354692", "susan@gmail.com", 0, "Bd 1, Pro 1");
        Alumno a4 = new Alumno("Pepe", "73498399P", "492849288", "pepe@gmail.com", 9, "Bd 2, Pro 1");
        
        Alumno[] Alumnos = {a1,a2,a3,a4};
        System.out.println(Arrays.toString(Alumnos));
        Arrays.sort(Alumnos);
        System.out.println(Arrays.toString(Alumnos));
        ComparaAlumnoPorTelefono c = new ComparaAlumnoPorTelefono();
        Arrays.sort(Alumnos,c);
        System.out.println(Arrays.toString(Alumnos));
        

    }

  
    
}
