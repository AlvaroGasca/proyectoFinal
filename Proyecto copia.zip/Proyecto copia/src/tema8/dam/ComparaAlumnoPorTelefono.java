/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema8.dam;

import java.util.Comparator;

/**
 *
 * @author alvarogasca
 */
public class ComparaAlumnoPorTelefono implements Comparator{
    @Override
    public int compare(Object o1, Object o2) {
        
        return ((Alumno) o1).telefono.compareTo(((Alumno) o2).telefono);
    }
}
