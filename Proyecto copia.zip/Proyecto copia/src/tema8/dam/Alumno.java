/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema8.dam;



/**
 *
 * @author alvarogasca
 */
public class Alumno implements Comparable{
    String nombre;
    String dni;
    String telefono;
    String email;
    int dormir;
    String asignaturas;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getDormir() {
        return dormir;
    }

    public void setDormir(int dormir) {
        this.dormir = dormir;
    }

    public String getAsignaturas() {
        return asignaturas;
    }

    public void setAsignaturas(String asignaturas) {
        this.asignaturas = asignaturas;
    }
    
    

    public Alumno(String nombre, String dni, String telefono, String email, int dormir, String asignaturas) {
        this.nombre = nombre;
        this.dni = dni;
        this.telefono = telefono;
        this.email = email;
        this.dormir = dormir;
        this.asignaturas = asignaturas;
    }

    @Override
    public int compareTo(Object o) {
        Alumno otroAlumno = (Alumno) o;
        
        if(dormir < otroAlumno.dormir){
            return -1;
        }
        if(dormir > otroAlumno.dormir){
            return 1;
        }else{
        return 0;
        }
    }
    
    public boolean empiezaPor6(){
        if(this.telefono.startsWith("6")){
            return true;
        }else{
            return false;
        }
    }
    
    @Override
    public String toString() {
        return "Alumno{" + "nombre=" + nombre + ", dni=" + dni + ", telefono=" + telefono + ", email=" + email + ", dormir=" + dormir + ", asignaturas=" + asignaturas + '}';
    }
}
