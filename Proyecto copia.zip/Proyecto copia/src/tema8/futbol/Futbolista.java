/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema8.futbol;

import java.util.Objects;

/**
 *
 * @author alvarogasca
 */
public class Futbolista implements Comparable{
    String dni;
    String nombre;
    int edad;
    int goles;

    public Futbolista(String dni, String nombre, int edad, int goles) {
        this.dni = dni;
        this.nombre = nombre;
        this.edad = edad;
        this.goles = goles;
    }

    @Override
    public String toString() {
        return "Futbolista{" + "dni=" + dni + ", nombre=" + nombre + ", edad=" + edad + ", goles=" + goles + '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Futbolista otro = (Futbolista) obj;
        return Objects.equals(this.dni, otro.dni);
    }

    @Override
    public int compareTo(Object otro) {

        int resultado;
        Futbolista otroFutbolista = (Futbolista) otro;
        if (otroFutbolista.dni.charAt(0) > dni.charAt(0)){ 
        resultado = -1; 
        }else if(dni.charAt(0) > otroFutbolista.dni.charAt(0)){ 
        resultado = 1;
        }else{ 
        resultado = 0;
        }
        return resultado;
    }
    
    
}
