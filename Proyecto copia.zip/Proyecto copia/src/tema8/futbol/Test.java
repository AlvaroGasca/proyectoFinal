/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema8.futbol;

import java.util.Arrays;

/**
 *
 * @author alvarogasca
 */
public class Test {
    public static void main(String[] args) {
        Futbolista f1 = new Futbolista("183010A", "Alvaro", 23, 2);
        Futbolista f2 = new Futbolista("284008F", "Luz", 21, 4);
        Futbolista f3 = new Futbolista("292839Y", "Miguel", 31, 9);
        Futbolista f4 = new Futbolista("745835L", "Jose", 19, 4);
        
        Futbolista[] futbolista = {f1,f2,f3,f4};
        Arrays.sort(futbolista);
        System.out.println(Arrays.toString(futbolista));
        
        ComparaFutbolistaPorGoles c = new ComparaFutbolistaPorGoles();
        Arrays.sort(futbolista,c);
        System.out.println(Arrays.toString(futbolista));
    }
}
