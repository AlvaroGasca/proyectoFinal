/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema8.futbol;

import java.util.Comparator;

/**
 *
 * @author alvarogasca
 */
public class ComparaFutbolistaPorGoles implements Comparator{

    @Override
    public int compare(Object o1, Object o2) {
        int resultado;
        Futbolista otroFutbolista = (Futbolista) o1;
        Futbolista otroFutbolista2 = (Futbolista) o2;
        if (otroFutbolista.goles > otroFutbolista2.goles){ 
        resultado = -1; 
        }else if(otroFutbolista2.goles > otroFutbolista.goles){ 
        resultado = 1;
        }else{ 
        resultado = 0;
        }
        return resultado;
    }
    
}
