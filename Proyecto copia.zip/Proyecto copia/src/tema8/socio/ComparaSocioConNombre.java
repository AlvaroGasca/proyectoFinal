/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema8.socio;

import java.util.Comparator;

/**
 *
 * @author alvarogasca
 */
public class ComparaSocioConNombre implements Comparator{

    @Override
    public int compare(Object o1, Object o2) {
//       int resultado;
//    Socio otroSocio = (Socio) o1;
//    Socio otroSocio2 = (Socio) o2;
//    if (otroSocio.nombre < otroSocio2.nombre){ //this va antes que otroSocio
//    resultado = -1; //o cualquier número negativo
//    }else if(otroSocio.nombre > otroSocio2.nombre){ //this va después que otroSocio
//    resultado = 1; //o cualquier número positivo
//    }else{ //this es igual que otroSocio
//    resultado = 0;
//    }
//    return resultado;
    return ((Socio) o1).nombre.compareTo(((Socio) o2).nombre);
    }
   
}
