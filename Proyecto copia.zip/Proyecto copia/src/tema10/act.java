/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema10;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class act {
    public static void main(String[] args) {
         ArrayList<Integer> numeros = new ArrayList<>();
         Scanner sc = new Scanner(System.in);
         
         System.out.println("Inserta los numeros (-1 para salir): ");
         while(true){
             System.out.println("Inserta un numero: ");
             int n = sc.nextInt();
             
             if(n==-1){
                 break;
             }
             numeros.add(n);
         }
         
         System.out.println("Los numeros ingresados son: ");
         System.out.println(numeros.toString());
         
         System.out.println("Los numeros pares son: ");
         for(int n:numeros){
             if(n % 2 == 0){
                 System.out.println(n);
             }
         }
    }
}
