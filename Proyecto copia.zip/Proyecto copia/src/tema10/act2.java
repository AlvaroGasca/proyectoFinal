/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema10;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;

/**
 *
 * @author alvarogasca
 */
public class act2 {
    public static void main(String[] args) {
        ArrayList<Integer> numeros = new ArrayList<>();
        Random rd = new Random();
        
        for(int i=0; i<20; i++){
            int n = rd.nextInt(10)+1;
            numeros.add(n);
        }
        
        System.out.println("La lista es: " + numeros);
        
        Set<Integer> nuevaLista = new LinkedHashSet<>(numeros);
        System.out.println(nuevaLista);
    }
}
