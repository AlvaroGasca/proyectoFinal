/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema10;

import java.util.HashMap;
import java.lang.Integer;

/**
 *
 * @author alvarogasca
 */
public class Map {
    public static void main(String[] args) {
        HashMap<String, Integer> m = new HashMap<>();
        m.put("Pedro",121);
    }
    
}
