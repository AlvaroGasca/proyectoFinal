/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema10;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author alvarogasca
 */
public class act3 {
    public static void main(String[] args) {
    ArrayList<Integer> numeros = new ArrayList<>();
        Random rd = new Random();
        
        for(int i=0; i<100; i++){
            int n = rd.nextInt(10)+1;
            numeros.add(n);
        }
    }    
}
