/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema2;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Par {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Inserta a: ");
        int a = sc.nextInt();
        
       if (a%2==0){
            System.out.println("El numero es par");
       }
       
       //if (a%2!=0){
           // System.out.println("El numero es impar");
      // }
      
       else{
           System.out.println("El numero es impar");
       }
    }
}

