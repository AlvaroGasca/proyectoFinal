/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema2;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Casi_cero {
    public static void main(String[] args) {
        
      Scanner sc = new Scanner(System.in);
      System.out.println("Inserta a: ");
      double a = sc.nextDouble();
      
      if ((-1<a) && (a<1) && !(a==0)){
          System.out.println("El numero es casi-cero ");
      }
      
      else{
          System.out.println("El numero no es casi-cero ");
      }
    }
}
