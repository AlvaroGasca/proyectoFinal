/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema2;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Notas {
    public static void main(String[] args) {
        
      Scanner sc = new Scanner(System.in);
      System.out.println("Inserta la nota: ");
      int a = sc.nextInt();
    
      if ((a<5) && (a>=0)){
          System.out.println("Insuficiente");
      }
      
      else if (a==5){
          System.out.println("Suficiente");
      }
      
      else if (a==6){
          System.out.println("Bien");
      }
      
      else if ((a==7) || (a==8)){
          System.out.println("Notable");
      }
      
      else if ((a==9) || (a==10)){
          System.out.println("Sobresaliente");
      }
      
      else{
          System.out.println("La nota debe ser un numero entero entre 0 y 10");
      }
    }
}
