/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema2;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Pedir_hora {
    public static void main(String[] args) {      
      Scanner sc = new Scanner(System.in);
      System.out.println("¿Qué hora es? ");
            System.out.println("Diga la hora:");
            int hora = sc.nextInt();
            System.out.println("Diga los minutos:");
            int minutos = sc.nextInt();
            System.out.println("Diga los segundos:");
            int segundos = sc.nextInt();
          
          if (hora>24 || minutos>60 || segundos>60){
              System.out.println("La hora no es correcta");
          }
          else{
            
            segundos = segundos+1;
            
          if (segundos==60){
          segundos = 00;
          minutos = minutos+1;
      }
          if (minutos==60){
          minutos = 00;
          hora = hora+1;
      }
          if (hora==24){
              hora = 00;
          }
         
            
      System.out.println("Son las: " + hora + ":" + minutos + ":" + segundos);
          }
    }
}
