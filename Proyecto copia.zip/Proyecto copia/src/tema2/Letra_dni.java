/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema2;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Letra_dni {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("introduzca DNI sin letra ");
        int DNI = sc.nextInt();
        int letra = DNI%23;
        
        if (DNI<=999999999 && DNI>0) {
        switch(letra){
            case 0:
                System.out.println("La letra es T ");
                break;
             case 1:
                System.out.println("La letra es R ");
                 break;
             case 2:
                System.out.println("La letra es W ");
                 break;
             case 3:
                System.out.println("La letra es A ");
                 break;
             case 4:
                System.out.println("La letra es G ");
                 break;
             case 5:
                System.out.println("La letra es M ");
                 break;
             case 6:
                System.out.println("La letra es Y ");
                 break;
             case 7:
                System.out.println("La letra es F ");
                 break;
             case 8:
                System.out.println("La letra es P ");
                 break;
             case 9:
                System.out.println("La letra es D ");
                 break;
             case 10:
                System.out.println("La letra es X ");
                 break;
             case 11:
                System.out.println("La letra es B ");
                 break;
             case 12:
                System.out.println("La letra es N ");
                 break;
             case 13:
                System.out.println("La letra es J ");
                 break;
             case 14:
                System.out.println("La letra es Z ");
                 break;
             case 15:
                System.out.println("La letra es S ");
                 break;
             case 16:
                System.out.println("La letra es Q ");
                 break;
             case 17:
                System.out.println("La letra es V ");
                 break;
             case 18:
                System.out.println("La letra es H ");
                 break;
             case 19:
                System.out.println("La letra es L ");
                 break;
             case 20:
                System.out.println("La letra es C ");
                 break;
             case 21:
                System.out.println("La letra es K ");
                 break;
             case 22:
                System.out.println("La letra es E ");
                 break;
                 }
        }else{
            System.out.println("No es valido");
        }

    }
}
    

