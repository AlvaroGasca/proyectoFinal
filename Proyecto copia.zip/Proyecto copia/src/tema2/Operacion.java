/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema2;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Operacion {
    public static void main(String[] args) {      
      Scanner sc = new Scanner(System.in);
      System.out.println("Ingresa el primer numero: ");
      int a = sc.nextInt();
      
      System.out.println("Ingresa el segundo numero: ");
      int b = sc.nextInt();
      
      System.out.println("Ingresa operador(-,+,*,/): ");
      char operador = sc.next().charAt(0);
      
      switch(operador){
          case '-' : int resta= a-b; System.out.println("La resta es " + a + " - " + b + " = " + resta);break;
          case '+': int suma=a+b; System.out.println("La suma es " + a + " + " + b + " = " + suma); break;
          case '*': int multiplicacion=a*b; System.out.println("La multiplicacion es " + a + " * " + b + " = " + multiplicacion); break;
          case '/': int division=a/b; System.out.println("La division es " + a + " / " + b + " = " + division); break;
          default: System.out.println("Error"); break;
    }
}
}
