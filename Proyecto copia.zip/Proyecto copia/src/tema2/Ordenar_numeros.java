/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema2;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Ordenar_numeros {
    public static void main(String[] args) {
        
      Scanner sc = new Scanner(System.in);
      System.out.println("Inserta a: ");
      int a = sc.nextInt();
      
      System.out.println("Inserta b: ");
      int b = sc.nextInt();
      
      System.out.println("Inserta c: ");
      int c = sc.nextInt();
      
      if ((a>=b) && (b>c)){
          System.out.println("El orden es: " + a + " > "+ b + " > " + c);
      }
    
      else if ((b>=a) && (a>c)){
          System.out.println("El orden es: " + b + " > "+ a + " > " + c);
      }
      
      else if ((c>=a) && (a>b)){
          System.out.println("El orden es: " + c + " > " + a + " > " + b);
      }
      
      else if ((b>=c) && (c>a)){
          System.out.println("El orden es: " + b + " > " + c + " > " + a);
      }
      
      else if ((a>=c) && (c>b)){
          System.out.println("El orden es: " + a + " > " + c + " > " + b);
      }
      
      else{
          System.out.println("El orden es: " + c + " > " + b + " > " + a);
      }
    }
}
