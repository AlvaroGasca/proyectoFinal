/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema2;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Multiplo {
     public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        System.out.println("Intriduce el primer numero ");  
        int b = sc.nextInt();
        System.out.println("Introduce el segundo numero ");
        boolean resultado = (a%b==0) && (a>=b);
        System.out.println(a + " es multiplo de "+ b +" " + resultado);
         
   } 
   
}
