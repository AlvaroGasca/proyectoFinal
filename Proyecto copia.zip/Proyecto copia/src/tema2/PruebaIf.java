/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema2;

/**
 *
 * @author alvarogasca
 */
public class PruebaIf {
    public static void main(String[] args) {
        int a=3;
        if (a + 1 < 10) {
            a = 0;
            System.out.println("Hola");
        }
         System.out.println("El valor de a es: " + a);
 }   
}
