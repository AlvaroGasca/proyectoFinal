/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema3;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Prueba {
    public static void main(String[] args) {
        Scanner numeros= new Scanner(System.in);
        System.out.println("Introduce un numero");
        int num1=numeros.nextInt();
        System.out.println("Introduce otro numero");
        int num2=numeros.nextInt();
        if(num1>num2){
            System.out.println("El " + num1 + " es el mayor");
            
        }else{
            System.out.println("El " + num2 + " es el mayor");
        }
    }
    
}
