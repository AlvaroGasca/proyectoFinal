/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema3;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Repetir {
    public static void main(String[] args){
    Scanner sc = new Scanner (System.in);
    int numero=1;
    
    while(numero!=0){
        
        System.out.println("Introduce un numero");
        numero=sc.nextInt();
        
        if (numero%2==0){
            System.out.println("El numero es par");
        }
        
        if (numero%2!=0){
            System.out.println("El numero es impar");
        }
        
        if (numero==0){
            System.out.println("Fin del proceso");break;
        }
    }
}
}


