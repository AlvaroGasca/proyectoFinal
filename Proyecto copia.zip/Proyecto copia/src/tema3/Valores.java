/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema3;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Valores {
     public static void main(String[] args){
Scanner sc = new Scanner (System.in);
        int contador = 1;
        int numero;
        int suma = 0;
        int promedio = 0;
        
        while (contador<=10){
            System.out.println("Ingrese un numero: ");
            numero = sc.nextInt();
            suma += numero;
            promedio= suma/contador;
            contador++;
                    }
        System.out.println("Suma= " +suma);
        System.out.println("Promedio= " +promedio);
        }
}
