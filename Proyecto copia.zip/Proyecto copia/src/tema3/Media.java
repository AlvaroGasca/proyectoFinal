/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema3;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Media {
    public static void main(String[] args) {
        System.out.println("Inserta 10 numero enteros:");
        int a;
        int suma = 0;
        for(int n=0; n<10; n++){
        Scanner sc = new Scanner(System.in);
        System.out.println("Inserta un numero:");
        a = sc.nextInt();
        suma+=a;
        }
        int media=suma/10;
        System.out.println("La media es:" + media);
    }
    
}
