/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema3;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Calculo_mental {
    public static void main (String[]Args){
       Scanner sc = new Scanner(System.in);
       int numeroAleatorio = 0;
       int numeroAleatorio2 = 0;
       int entrada = 0;
       int contador = 0;
       int suma = 0;
       Random rd = new Random();
       
       do{
           numeroAleatorio = rd.nextInt(101);
           numeroAleatorio2 = rd.nextInt(101);
           suma=numeroAleatorio+numeroAleatorio2;
           System.out.println("La suma de " + numeroAleatorio + " y " + numeroAleatorio2 + " es: ");
           entrada= sc.nextInt();
           if(entrada==suma){
           contador++;
           System.out.println("Has acertado, continua: ");
           }
           
        }while (entrada==suma);
       
           System.out.println("Te has equivocado, numero de aciertos: " + contador);

        }
}   
