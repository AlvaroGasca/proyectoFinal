/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema3;



/**
 *
 * @author alvarogasca
 */
public class Bucle {
    public static void main(String[] args){
    int numero =0;
    while(numero<=50){
        System.out.println(numero);
    numero+=2;
}
}
}