/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema3;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Diez_numeros {
     public static void main(String[] args){
    Scanner sc = new Scanner (System.in);
    int a; 
    int contador=0;
    int suma=0;
    
    do{
        System.out.println("Introduce un numero");
        a=sc.nextInt();
        contador++;
        suma+=a;
        
    }while(contador<10);
    System.out.println("El resultado es " + suma);
    }
}
