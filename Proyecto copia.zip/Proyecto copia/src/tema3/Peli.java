/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema3;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Peli {
    public static void main (String[]Args){
       Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un numero: ");
        int a=sc.nextInt();
       for (int numero = 0; numero<a; numero++){
           System.out.println("¿Hoy vamos a ver una peli?");
       }
    }
}
    
