/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema3;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Multiplos7 {
    public static void main (String[]Args){
        System.out.println("Presiona 0 para empezar: ");
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        if (n==0){
        for(int i=0; i<100; i+=7){
            System.out.println(i);
        }
      }else{
            System.out.println("No has presionado la tecla correcta ");
        }
    }
}
