/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema3;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Dos_numeros {
    public static void main(String[] args){
    Scanner sc = new Scanner (System.in);
    int a,b;
    
    do{
        System.out.println("Introduce dos numeros: ");
        a=sc.nextInt();
        b=sc.nextInt();
        System.out.println("Los numeros no son iguales");
        
    }while(a!=b);
        System.out.println("Los numeros son iguales");
    }
}
