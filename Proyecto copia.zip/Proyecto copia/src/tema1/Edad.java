/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema1;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Edad { 
    public static void main(String[] args) {
    Scanner sc = new Scanner (System.in);
    int edad = sc.nextInt();
    
    System.out.println("Su edad es de"+ edad +1);
}
    }
