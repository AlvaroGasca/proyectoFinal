/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema1;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Media_Notas {
    public static void main(String[] args) {
        int numeroIntermedio=0;
                 int total=0;
                 Scanner sca =new Scanner (System.in);
                 System.out.println("Dime el número de personas");
                 int numero =sca.nextInt();
                 for (int i=0; i<numero; i++){
                                  System.out.println("Dime la nota de la persona número "+i+"n");
                                  numeroIntermedio=sca.nextInt();                                                    
                                  total=total+numeroIntermedio;
                                  } 
                 int media =(int) (total/numero);
                 System.out.println("La media es "+media);


    
}
}
