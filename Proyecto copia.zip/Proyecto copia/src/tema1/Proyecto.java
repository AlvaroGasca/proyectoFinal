/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tema1;

/**
 *
 * @author alvarogasca
 */
public class Proyecto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
final double pi=3.141592;
double diametro=18;
double r=diametro/2;


double areaDelCirculo=2*pi*r*r;



       
  
        // TODO code application logic here
        System.out.println("El area del circulo cuyo radio es " + r + " es " + areaDelCirculo);
    }
    
}
