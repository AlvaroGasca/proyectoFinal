/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema1;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Fruta {
    public static void main(String[] args) {
       Scanner sc= new Scanner (System.in);
       double manzanas, peras;
       System.out.println("Introduzca los kilos de manzanas: ");
       manzanas = sc.nextDouble();
       
       System.out.println("Introduzca los kilos de peras: ");
       peras = sc.nextDouble();
       double precio_manzanas = manzanas*2.35;
       double precio_peras = peras*1.95; 
       
       System.out.println(("El precio de las manzanas es de: " + precio_manzanas) 
               + (" El precio de las peras es de: " + precio_peras));
    }
    
}
