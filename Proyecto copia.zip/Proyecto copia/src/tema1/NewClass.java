/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema1;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class NewClass {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        System.out.println("Ingrese un numero entero positivo: ");
        
        int a = sc.nextInt();
        if(a>=0){
            if(a%2==0){
                System.out.println("Es par ");
            }else{
                System.out.println("Es impar ");
            }
        }else{
            System.out.println("Debe ingresar un numero positivo ");
        }
        
    }
}
