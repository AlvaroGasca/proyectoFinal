/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema1;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Escaner{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        mesage("Hola");
        //API util
        double numero = sc.nextDouble();
        System.out.println("Su numero es:" +numero);
    
}

    private static void mesage(String hola) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    }
    
