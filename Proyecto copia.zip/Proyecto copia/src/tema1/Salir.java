/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema1;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Salir {
    public static void main(String[] args) {
    
        Scanner sc = new Scanner (System.in);
        System.out.println("¿Está lloviendo?");
        boolean lluvia = sc.nextBoolean();
        
        System.out.println("¿Has terminado la tarea?");
        boolean tarea = sc.nextBoolean();
        
        System.out.println("¿Tienes que ir a la biblioteca?");
        boolean biblioteca = sc.nextBoolean();
        boolean salir = (lluvia==false&&tarea==true) || (biblioteca==true);
        System.out.println("¿Puedes salir a la calle?" + salir);
        
}
    
}
