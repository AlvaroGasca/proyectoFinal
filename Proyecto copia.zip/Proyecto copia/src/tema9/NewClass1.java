/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema9;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
/**
 *
 * @author alvarogasca
 */
public class NewClass1 {
    public static void main(String[] args) {
        BufferedReader in = null;

        try{
            in = new BufferedReader(new FileReader("quijote.txt"));
            String linea;
            while ((linea = in.readLine()) != null) {
                System.out.println(linea);
            }
            in.close();
        }catch (IOException e){
            System.out.println("Error al leer el archivo: " + e.getMessage());
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    System.out.println("Error al cerrar el archivo: " + e.getMessage());
                }
            }
        }
    }
}