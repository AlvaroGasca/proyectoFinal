/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema9.numero_entero;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Numero{
    static Integer leerEntero(){
Integer resultado;
while (true){
try{
System.out.println("Introducir entero: ");
resultado = new
Scanner(System.in).nextInt();
break;
}catch(InputMismatchException ex){
System.out.println("Tipo erróneo");
}
}
return resultado;
}
}
