/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema9.numero_entero;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Leer {

    static int leerEntero(){
        Scanner sc = new Scanner(System.in);
        int resultado = 0;
        
        try{
            System.out.println("Introducir entero: ");
            resultado = sc.nextInt();
            
        }catch(InputMismatchException ex){
            System.out.println("Tipo erróneo");
        }
        
        return resultado;
    }

}

