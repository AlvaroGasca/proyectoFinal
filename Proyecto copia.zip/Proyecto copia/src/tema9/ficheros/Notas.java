/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema9.ficheros;

import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author alvarogasca
 */
public class Notas {
    public static void main(String[] args) {
        FileReader in = null;
        try{
        //  in= new FileReader("C:\\Users\\usuario\\Desktop\\nota.txt"); //Ruta absoluta
            in= new FileReader("nota.txt"); //Ruta relativa
        }catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }
}
