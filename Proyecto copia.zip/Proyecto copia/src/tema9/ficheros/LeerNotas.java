/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema9.ficheros;

import java.io.FileReader;

/**
 *
 * @author alvarogasca
 */
public class LeerNotas {
    public static void main(String[] args) {
        
        String texto ="";
        FileReader in = null;
        
       // try{
       //     in = new FileReader("nota.txt");
       // }
    }
}
