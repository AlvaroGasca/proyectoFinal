/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema9;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class NewClass {
    public static void main(String[] args) {
        BufferedReader in = null;
        BufferedWriter out = null;
        
        try{
                in= new BufferedReader(new FileReader("texto.txt"));
                out= new BufferedWriter(new FileWriter("texto.txt"));
                out.write("hola");
                out.newLine();
                out.flush();
                 String linea = in.readLine();
            while (linea != null) { //hasta el final del fichero
                Scanner s = new Scanner(linea);
                linea = in.readLine();
            }
            
            out.close();
        } catch (IOException e){
            System.out.println("nop");
        }
    }
}
