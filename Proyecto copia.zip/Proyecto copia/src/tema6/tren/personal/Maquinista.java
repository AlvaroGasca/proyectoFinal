/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.tren.personal;

/**
 *
 * @author alvarogasca
 */
public class Maquinista {
    private String nombre;
    private String dni;
    private int sueldo;
    private String rango;
    
    Maquinista(String nombre, String dni, int sueldo, String rango){
        this.nombre=nombre;
        this.dni=dni;
        this.sueldo=sueldo;
        this.rango=rango;
    }
    
}
