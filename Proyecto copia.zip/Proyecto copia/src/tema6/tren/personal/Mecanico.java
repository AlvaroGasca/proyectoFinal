/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.tren.personal;

/**
 *
 * @author alvarogasca
 */
public class Mecanico {
    private String nombre;
    private String telefono;
    private Especialidades especialidad;
    
}
enum Especialidades{frenos,hidraulica,electricidad,motor}