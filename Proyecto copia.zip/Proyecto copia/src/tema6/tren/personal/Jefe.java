/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.tren.personal;

import java.time.LocalDate;

/**
 *
 * @author alvarogasca
 */
public class Jefe {
    private String nombre;
    private String dni;
    private LocalDate fecha;
    
    Jefe(String nombre, String dni, LocalDate fecha){
        this.dni=dni;
        this.fecha=fecha;
        this.nombre=nombre;
    }
    
}
