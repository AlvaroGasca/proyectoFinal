/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.formulario_Huelga;

import java.util.Date;

/**
 *
 * @author alvarogasca
 */
public class NewClass {
    String nombre;
    final String dni = null;
    Date fecha;
    String firma;
    boolean asiste;
    
}
