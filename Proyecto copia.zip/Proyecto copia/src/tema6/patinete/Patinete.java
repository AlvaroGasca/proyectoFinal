/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.patinete;

/**
 *
 * @author alvarogasca
 */
public class Patinete {
    private String id;
    private String modelo;
    private String marca;
    private Colores color;
    private int potencia;
    
    
    
    Patinete(String id, String modelo, String marca, Colores color, int potencia){
        this.id=id;
        this.modelo=modelo;
        this.marca=marca;
        this.color=color;
        this.potencia=potencia;
    }

    @Override
    public String toString() {
        return "Patinete{" + "id=" + id + ", modelo=" + modelo + ", marca=" + marca + ", color=" + color + ", potencia=" + potencia + '}';
    }
    
}
enum Colores{GRIS,AMARILLO,AZUL}
