/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.patinete;

import java.time.LocalDate;

/**
 *
 * @author alvarogasca
 */
public class TestPatinete {
    public static void main(String[] args) {
        Patinete p = new Patinete("646A","Sec","Zeus",Colores.AMARILLO, 54);
        Cliente c = new Cliente("74645765H","Manuel","Gasca Gallego","Calle Velazquez","646A","3775485758");
        Tecnicos t = new Tecnicos("73476457P","Pedro","Garcia Jimenez",LocalDate.now(),1000);
        FichaTecnicaPatinete f1 = new FichaTecnicaPatinete(c, t);
        
        System.out.println(f1);
        
        f1.setReparacion(LocalDate.of(2022,5,25));
        
    }
}
