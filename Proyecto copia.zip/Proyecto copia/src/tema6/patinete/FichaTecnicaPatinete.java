/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.patinete;

import java.time.LocalDate;

/**
 *
 * @author alvarogasca
 */
public class FichaTecnicaPatinete {
    private Cliente cliente;
    private Tecnicos tecnico;
    private LocalDate reparacion;
    private double horas;
    
    public FichaTecnicaPatinete(Cliente cliente, Tecnicos tecnico){
        
        this.cliente = cliente;
        this.tecnico = tecnico;
    }

    public LocalDate getReparacion() {
        return reparacion;
    }

    public void setReparacion(LocalDate reparacion) {
        this.reparacion = reparacion;
    }

    public double getHoras() {
        return horas;
    }

    public void setHoras(double horas) {
        this.horas = horas;
    }
    
    

    @Override
    public String toString() {
        return "FichaTecnicaPatinete{" + "cliente=" + cliente + ", tecnico=" + tecnico + ", reparacion=" + reparacion + ", horas=" + horas + '}';
    }
    
}
