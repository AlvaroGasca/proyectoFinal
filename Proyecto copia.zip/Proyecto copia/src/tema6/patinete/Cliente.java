/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.patinete;

/**
 *
 * @author alvarogasca
 */
public class Cliente {
    private String dni;
    private String nombre;
    private String apellidos;
    private String direccion;
    private String patinete;
    private String telefono;
    
    Cliente(String dni, String nombre, String apellidos, String direccion, String patinete, String telefono){
        this.dni=dni;
        this.apellidos=apellidos;
        this.direccion=direccion;
        this.nombre=nombre;
        this.telefono=telefono;
        this.patinete=patinete;
    }

    @Override
    public String toString() {
        return "Cliente{" + "dni=" + dni + ", nombre=" + nombre + ", apellidos=" + apellidos + ", direccion=" + direccion + ", patinete=" + patinete + ", telefono=" + telefono + '}';
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    
    
    
}
