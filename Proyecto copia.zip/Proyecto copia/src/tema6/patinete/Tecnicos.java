/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.patinete;

import java.time.LocalDate;

/**
 *
 * @author alvarogasca
 */
public class Tecnicos {
    private String dni;
    private String nombre;
    private String apellidos;
    private LocalDate fecha;
    private int salario;
    
    Tecnicos(String dni, String nombre, String apellidos, LocalDate fecha, int salario){
        this.apellidos=apellidos;
        this.dni=dni;
        this.fecha=fecha;
        this.nombre=nombre;
        this.salario=salario;
        
    }

    @Override
    public String toString() {
        return "Tecnicos{" + "dni=" + dni + ", nombre=" + nombre + ", apellidos=" + apellidos + ", fecha=" + fecha + ", salario=" + salario + '}';
    }
    
    
    
}
