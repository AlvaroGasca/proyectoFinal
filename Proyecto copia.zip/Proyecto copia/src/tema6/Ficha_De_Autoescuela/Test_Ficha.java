/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.Ficha_De_Autoescuela;

/**
 *
 * @author alvarogasca
 */
public class Test_Ficha {
    public static void main(String[] args) {
        Profesor p = new Profesor("52376527S","Miguel",1500);
        Alumno a = new Alumno("25347898A","Luis","B");
        Coche c = new Coche("6234TRG","Seat","Leon");
        
        System.out.println("DNI del alumno: " + a.dni);
        System.out.println("Matricula del coche: "+ c.matricula);
    }
    
}
