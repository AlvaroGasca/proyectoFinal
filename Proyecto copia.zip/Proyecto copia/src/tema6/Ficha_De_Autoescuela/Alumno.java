/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.Ficha_De_Autoescuela;

/**
 *
 * @author alvarogasca
 */
public class Alumno {
    String dni;
    String nombre;
    String carnet;
    
    Alumno(String dni, String nombre,String carnet){
        this.dni=dni;
        this.nombre=nombre;
        this.carnet=carnet;
    }
    
}
