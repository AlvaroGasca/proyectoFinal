/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.hora;

import java.util.Scanner;

/**
 *
 * @author alvarogasca
 */
public class Test_Hora {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Hora h = new Hora();
        
        System.out.println("Introduce las horas: ");
        h.sethora(sc.nextInt());
        System.out.println("Introduce los minutos: ");
        h.setminuto(sc.nextInt());
        System.out.println("Introduce los segundos: ");
        h.setsegundo(sc.nextInt());
        System.out.println("Introduce el numero de segundos que quieres sumar: ");
        int n = sc.nextInt();
        
        int totalSegundos = (h.gethora() * 3600) + (h.getminuto() * 60) + (h.getsegundo());
        totalSegundos += n;
        int nuevaHora = totalSegundos / 3600;
        int nuevoMinuto = (totalSegundos % 3600) / 60;
        int nuevoSegundo = (totalSegundos % 3600)% 60;
        Hora hora2 = new Hora(nuevaHora,nuevoMinuto,nuevoSegundo);
        
        System.out.println("La nueva hora es: " + hora2.gethora() + ":" + hora2.getminuto() + ":" + hora2.getsegundo());
        
    }
}
