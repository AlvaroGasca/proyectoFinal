/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.hora;

/**
 *
 * @author alvarogasca
 */
public class Hora {
    int hora;
    int minuto;
    int segundo;
    
    public Hora(){
    }
    
    Hora(int hora, int minuto, int segundo){
        this.hora=hora;
        this.minuto=minuto;
        this.segundo=segundo;
    }
    
    public int gethora(){
        return hora;
    }
    
    public void sethora(int hora){
        this.hora=hora;
    }
    
    public int getminuto(){
        return minuto;
    }
    
    public void setminuto(int minuto){
        this.minuto=minuto;
    }
    
    public int getsegundo(){
        return segundo;
    }
    
    public void setsegundo(int segundo){
        this.segundo=segundo;
    }
}
