/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.cuentacorriente;

/**
 *
 * @author alvarogasca
 */
public class Test_cuenta_corriente {
    public static void main(String[] args) {
        Cuenta_Corriente c = new Cuenta_Corriente("25473548X","Manuel",500);
        
        c.sacar_dinero(13.23);
        c.ingresar(50);
        c.estado();
        Cuenta_Corriente.setNombre_banco("BBVA");
        System.out.println(Cuenta_Corriente.getNombre_banco());
        
        Gestor g1 = new Gestor("Miguel","84294803");
        
        Cuenta_Corriente a = new Cuenta_Corriente("58657655F","Jose",200,g1);
        System.out.println(g1.gettelefono());
    }
    
    
}
