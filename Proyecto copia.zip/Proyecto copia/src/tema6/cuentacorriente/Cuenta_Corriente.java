/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.cuentacorriente;

/**
 *
 * @author alvarogasca
 */
public class Cuenta_Corriente {
    String dni;
    public String nombre;
    private double saldo;
    private static String Nombre_banco = "Santander";
    private Gestor gestor;
    
    Cuenta_Corriente(String dni, String nombre,double saldo){
        this.dni=dni;
        this.nombre=nombre;
        this.saldo=saldo;
    }
    
    Cuenta_Corriente(String dni, String nombre,double saldo, Gestor gestor){
        this.dni=dni;
        this.nombre=nombre;
        this.saldo=saldo;
        this.gestor=gestor;
    }
    
    void sacar_dinero(double sacar){
        if(sacar<=saldo){
            double a;
            a=saldo-sacar;
            saldo=a;
            System.out.println("Saldo actual: " +saldo+ " Dinero sacado: " +sacar);
        }
        if(sacar>saldo){
            System.out.println("Saldo excaso: " +saldo);
        }
    }
    void ingresar(double meter){
        if(meter>0){
            double a;
            a=meter+saldo;
            saldo=a;
            System.out.println("Ingreso realizado, saldo actual: " +saldo);
        }
        if(meter<0){
            System.out.println("Ingreso incorrecto, el ingreso debe de ser de al menos 0,01€");
        }
    }
    void estado(){
        System.out.println("Saldo actual: " +saldo+ " Cliente: " +nombre+ " DNI: " +dni);
        
    }
    
    public static void setNombre_banco(String Nombre_banco){
        Cuenta_Corriente.Nombre_banco=Nombre_banco;
    }
    
    public static String getNombre_banco(){
        return Nombre_banco;
    }
}
