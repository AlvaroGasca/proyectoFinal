/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.cuentacorriente;

/**
 *
 * @author alvarogasca
 */
public class Gestor {
    public String nombre;
    private String telefono;
    int importe;
    
    Gestor(String nombre, String telefono){
        this.nombre=nombre;
        this.telefono=telefono;
        this.importe=10000;
    }
    
    public String gettelefono(){
        return this.telefono;
    }
    
    public String getnombre(){
        return this.nombre;
    }
    
    public void setnombre(String nombre){
        this.nombre=nombre;
    }
    
    public void setimporte(int importe){
        this.importe=importe;
    }
}
