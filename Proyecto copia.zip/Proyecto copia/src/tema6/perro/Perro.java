/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.perro;

/**
 *
 * @author alvarogasca
 */
public class Perro {
    String nombre;
    String raza;
    int edad;
    double estatura; 
    double peso;
    boolean vacuna;
    
    void ladrar(){
        System.out.println("Guau!!");
}
    void asustar(){
        for(int i=0;i<2;i++){
            ladrar();
        }
    }
    
    void sientate(){
        System.out.println("Sentado");
    }
}
