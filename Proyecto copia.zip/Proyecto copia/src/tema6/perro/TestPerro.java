/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.perro;

/**
 *
 * @author alvarogasca
 */
public class TestPerro {
    public static void main(String[] args) {
        Perro Jordan = new Perro();
        Jordan.edad = 5;
        Jordan.estatura = 2.3;
        Jordan.nombre = "Tor";
        Jordan.peso = 23.4;
        Jordan.raza = "beagle";
        Jordan.vacuna = true;
        
        Jordan.asustar();
        Jordan.sientate();
    }
}
