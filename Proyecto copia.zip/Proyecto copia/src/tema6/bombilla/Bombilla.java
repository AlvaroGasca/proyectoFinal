/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.bombilla;

/**
 *
 * @author alvarogasca
 */
public class Bombilla {
    public static boolean interruptorGeneral = true;
    private boolean interruptor;
    
    public Bombilla(){
        interruptor = true;   
    }
    
    public void enciende(){
        interruptor = true;
    }
    
    public void apaga(){
        interruptor = false;
    }
    
    public boolean estado(){
        return interruptorGeneral && interruptor;
    }
    
    public String muestraEstado(){
        String res;
        if(estado()){
            res= "Encendida";
        }else{
            res= "Apagada";
        }
        return res;
    }
    
}
    

