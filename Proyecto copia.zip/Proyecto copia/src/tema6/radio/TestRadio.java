/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.radio;

/**
 *
 * @author alvarogasca
 */
public class TestRadio {
    public static void main(String[] args) {
        Radio r = new Radio();
        r.setdown();
        System.out.println(r.getfrecuencia());
    }
    
}
