/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tema6.radio;

/**
 *
 * @author alvarogasca
 */
public class Radio {
    public double frecuencia;
    
    Radio(){
        this.frecuencia = 80;
    }
    
    public double getfrecuencia(){
        return this.frecuencia;
    }
    
    public void setup(){
        this.frecuencia=this.frecuencia+0.5;
        if(frecuencia>108){
            this.frecuencia=80;
        }
    }
    
    public void setdown(){
        this.frecuencia=this.frecuencia-0.5;
        if(frecuencia<80){
            this.frecuencia=108;
        }
    }
        
    
    
}
